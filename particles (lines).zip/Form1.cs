﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        private List<Particle> particles;
        private Timer timer;
        private Random random;
        private PointF mousePosition;

        public Form1()
        {
            InitializeComponent();
            particles = new List<Particle>();
            random = new Random();

            // Set up the timer
            timer = new Timer();
            timer.Interval = 16; // Approximately 60 FPS
            timer.Tick += Timer_Tick;
            timer.Start();

            // Double buffering for smooth rendering
            this.DoubleBuffered = true;

            // Set up mouse tracking
            this.MouseMove += Form1_MouseMove;

            // Create initial particles
            for (int i = 0; i < 150; i++) // Reduced number of particles for more spread
            {
                CreateParticle();
            }
        }

        private void Form1_MouseMove(object sender, MouseEventArgs e)
        {
            mousePosition = e.Location;
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            // Update particles
            float deltaTime = 0.016f; // Assuming 60 FPS
            foreach (var particle in particles)
            {
                particle.Update(deltaTime, this.ClientSize, mousePosition);
            }

            // Redraw the form
            this.Invalidate();
        }

        private void CreateParticle()
        {
            PointF position = new PointF(random.Next(this.Width), random.Next(this.Height));
            PointF velocity = new PointF((float)(random.NextDouble() * 2 - 1), (float)(random.NextDouble() * 2 - 1));
            float size = random.Next(2, 5); // Small particles
            float maxSpeed = random.Next(100, 200); // Increased speed range

            particles.Add(new Particle(position, velocity, size, maxSpeed));
        }

        protected override void OnPaint(PaintEventArgs e)
        {
            base.OnPaint(e);

            // Set high quality rendering for smoother lines and circles
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

            // Draw connections
            using (Pen pen = new Pen(Color.FromArgb(20, 255, 255, 255), 1)) // More transparent white
            {
                for (int i = 0; i < particles.Count; i++)
                {
                    for (int j = i + 1; j < particles.Count; j++)
                    {
                        float distance = DistanceBetween(particles[i].Position, particles[j].Position);
                        if (distance < 150) // Increased connection distance
                        {
                            e.Graphics.DrawLine(pen, particles[i].Position, particles[j].Position);
                        }
                    }
                }
            }

            // Draw particles
            foreach (var particle in particles)
            {
                particle.Draw(e.Graphics);
            }
        }

        private float DistanceBetween(PointF p1, PointF p2)
        {
            return (float)Math.Sqrt(Math.Pow(p2.X - p1.X, 2) + Math.Pow(p2.Y - p1.Y, 2));
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
