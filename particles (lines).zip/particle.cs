﻿using System;
using System.Drawing;

public class Particle
{
    public PointF Position { get; set; }
    private PointF _velocity;
    public PointF Velocity
    {
        get { return _velocity; }
        set { _velocity = value; }
    }
    public float Size { get; set; }
    public float MaxSpeed { get; set; }

    public Particle(PointF position, PointF velocity, float size, float maxSpeed)
    {
        Position = position;
        _velocity = velocity;
        Size = size;
        MaxSpeed = maxSpeed;
    }

    public void Update(float deltaTime, Size formSize, PointF mousePosition)
    {
        // Move the particle based on its velocity
        Position = new PointF(Position.X + _velocity.X * deltaTime, Position.Y + _velocity.Y * deltaTime);

        // Wrap around the form
        if (Position.X < 0) Position = new PointF(formSize.Width, Position.Y);
        if (Position.X > formSize.Width) Position = new PointF(0, Position.Y);
        if (Position.Y < 0) Position = new PointF(Position.X, formSize.Height);
        if (Position.Y > formSize.Height) Position = new PointF(Position.X, 0);

        // Create a "no-go" zone around the mouse
        float dx = Position.X - mousePosition.X;
        float dy = Position.Y - mousePosition.Y;
        float distanceToMouse = (float)Math.Sqrt(dx * dx + dy * dy);
        float noGoRadius = 100f; // Adjust this value to change the size of the "no-go" zone

        if (distanceToMouse < noGoRadius)
        {
            // Immediately push the particle outside the "no-go" zone
            float angle = (float)Math.Atan2(dy, dx);
            Position = new PointF(
                mousePosition.X + (float)Math.Cos(angle) * noGoRadius,
                mousePosition.Y + (float)Math.Sin(angle) * noGoRadius
            );

            // Add a burst of speed away from the mouse
            float pushForce = 500f;
            _velocity.X += (float)Math.Cos(angle) * pushForce * deltaTime;
            _velocity.Y += (float)Math.Sin(angle) * pushForce * deltaTime;
        }

        // Limit velocity to max speed
        float speed = (float)Math.Sqrt(_velocity.X * _velocity.X + _velocity.Y * _velocity.Y);
        if (speed > MaxSpeed)
        {
            _velocity.X = (_velocity.X / speed) * MaxSpeed;
            _velocity.Y = (_velocity.Y / speed) * MaxSpeed;
        }
    }

    public void Draw(Graphics g)
    {
        using (Brush brush = new SolidBrush(Color.White))
        {
            g.FillEllipse(brush, Position.X - Size / 2, Position.Y - Size / 2, Size, Size);
        }
    }
}