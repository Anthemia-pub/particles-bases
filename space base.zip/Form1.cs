﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        private List<Particle> particles = new List<Particle>();
        private Random random = new Random();
        private Timer timer = new Timer();
        public int ParticleCount = 200;

        public Form1()
        {
            this.DoubleBuffered = true;
            this.Size = new Size(800, 600);
            this.BackColor = Color.Black;

            timer.Interval = 10;
            timer.Tick += Timer_Tick;
            timer.Start();

            this.Paint += Form1_Paint;
            InitializeComponent();
            InitializeParticles();
            updatelabels();
        }

        private void InitializeParticles()
        {
            for (int i = 0; i < ParticleCount; i++)
            {
                CreateParticle();
            }
        }

        private void CreateParticle()
        {
            float x = (float)random.NextDouble() * this.ClientSize.Width;
            float y = (float)random.NextDouble() * this.ClientSize.Height;
            float speed = (float)random.NextDouble() * guna2TrackBar2.Value + 100;
            float size = (float)random.NextDouble() * guna2TrackBar1.Value + 1;
            int brightness = random.Next(128, 256);
            Color color = Color.FromArgb(brightness, brightness, brightness);

            particles.Add(new Particle(new PointF(x, y), speed, size, color));
        }

        private void Timer_Tick(object sender, EventArgs e)
        {
            UpdateParticles();
            this.Invalidate();
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            foreach (var particle in particles)
            {
                particle.Draw(e.Graphics);
            }
        }

        private void UpdateParticles()
        {
            float deltaTime = 0.016f;

            foreach (var particle in particles)
            {
                particle.Update(deltaTime, this.ClientSize.Height);
            }
        }

        private void guna2TrackBar1_Scroll(object sender, ScrollEventArgs e)
        {
            UpdateParticlesSize();
            updatelabels();
        }

        private void guna2TrackBar2_Scroll(object sender, ScrollEventArgs e)
        {
            UpdateParticlesSpeed();
            updatelabels();
        }

        private void UpdateParticlesSize()
        {
            foreach (var particle in particles)
            {
                particle.Size = (float)random.NextDouble() * guna2TrackBar1.Value + 1;
            }
        }
        private void UpdateParticlescolor()
        {
            foreach (var particle in particles)
            {
                int brightness = random.Next(guna2TrackBar3.Value, guna2TrackBar4.Value);
                Color color = Color.FromArgb(brightness, brightness, brightness);
                particle.Color = color;
            }
        }

        private void UpdateParticlesSpeed()
        {
            foreach (var particle in particles)
            {
                particle.Speed = (float)random.NextDouble() * guna2TrackBar2.Value + 100;
            }
        }
        private void UpdateParticlesnum()
        {
            int newParticleCount = guna2TrackBar5.Value;

            if (newParticleCount > particles.Count)
            {
                for (int i = particles.Count; i < newParticleCount; i++)
                {
                    CreateParticle();
                }
            }
            else if (newParticleCount < particles.Count)
            {
                particles.RemoveRange(newParticleCount, particles.Count - newParticleCount);
            }
        }

        private void guna2TrackBar3_Scroll(object sender, ScrollEventArgs e)
        {
            UpdateParticlescolor();
            updatelabels();
        }

        private void guna2TrackBar4_Scroll(object sender, ScrollEventArgs e)
        {
            UpdateParticlescolor();
            updatelabels();
        }
        public void updatelabels()
        {
            label1.Text = "size: " + guna2TrackBar1.Value;
            label2.Text = "speed: " + guna2TrackBar2.Value;
            label3.Text = "brightness: " + guna2TrackBar3.Value;
            label4.Text = "brightness #2: " + guna2TrackBar4.Value;
            label5.Text = "particle count: " + guna2TrackBar5.Value;
        }

        private void guna2TrackBar5_Scroll(object sender, ScrollEventArgs e)
        {
            UpdateParticlesnum();
            updatelabels();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
