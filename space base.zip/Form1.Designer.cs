﻿
namespace $safeprojectname$
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.guna2BorderlessForm1 = new Guna.UI2.WinForms.Guna2BorderlessForm(this.components);
            this.guna2TrackBar1 = new Guna.UI2.WinForms.Guna2TrackBar();
            this.guna2TrackBar2 = new Guna.UI2.WinForms.Guna2TrackBar();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.guna2TrackBar3 = new Guna.UI2.WinForms.Guna2TrackBar();
            this.label4 = new System.Windows.Forms.Label();
            this.guna2TrackBar4 = new Guna.UI2.WinForms.Guna2TrackBar();
            this.label5 = new System.Windows.Forms.Label();
            this.guna2TrackBar5 = new Guna.UI2.WinForms.Guna2TrackBar();
            this.SuspendLayout();
            // 
            // guna2BorderlessForm1
            // 
            this.guna2BorderlessForm1.BorderRadius = 10;
            this.guna2BorderlessForm1.ContainerControl = this;
            this.guna2BorderlessForm1.DockIndicatorTransparencyValue = 0.6D;
            this.guna2BorderlessForm1.ShadowColor = System.Drawing.Color.Cyan;
            this.guna2BorderlessForm1.TransparentWhileDrag = true;
            // 
            // guna2TrackBar1
            // 
            this.guna2TrackBar1.BackColor = System.Drawing.Color.Transparent;
            this.guna2TrackBar1.Location = new System.Drawing.Point(32, 29);
            this.guna2TrackBar1.Maximum = 10;
            this.guna2TrackBar1.Name = "guna2TrackBar1";
            this.guna2TrackBar1.Size = new System.Drawing.Size(300, 23);
            this.guna2TrackBar1.TabIndex = 0;
            this.guna2TrackBar1.ThumbColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(113)))), ((int)(((byte)(255)))));
            this.guna2TrackBar1.Value = 1;
            this.guna2TrackBar1.Scroll += new System.Windows.Forms.ScrollEventHandler(this.guna2TrackBar1_Scroll);
            // 
            // guna2TrackBar2
            // 
            this.guna2TrackBar2.BackColor = System.Drawing.Color.Transparent;
            this.guna2TrackBar2.Location = new System.Drawing.Point(32, 77);
            this.guna2TrackBar2.Maximum = 400;
            this.guna2TrackBar2.Minimum = 100;
            this.guna2TrackBar2.Name = "guna2TrackBar2";
            this.guna2TrackBar2.Size = new System.Drawing.Size(300, 23);
            this.guna2TrackBar2.TabIndex = 1;
            this.guna2TrackBar2.ThumbColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(113)))), ((int)(((byte)(255)))));
            this.guna2TrackBar2.Value = 200;
            this.guna2TrackBar2.Scroll += new System.Windows.Forms.ScrollEventHandler(this.guna2TrackBar2_Scroll);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Palatino Linotype", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(155, 7);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(34, 19);
            this.label1.TabIndex = 2;
            this.label1.Text = "size";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Palatino Linotype", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(155, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(45, 19);
            this.label2.TabIndex = 3;
            this.label2.Text = "speed";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Palatino Linotype", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(155, 103);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(78, 19);
            this.label3.TabIndex = 5;
            this.label3.Text = "brightness";
            // 
            // guna2TrackBar3
            // 
            this.guna2TrackBar3.BackColor = System.Drawing.Color.Transparent;
            this.guna2TrackBar3.Location = new System.Drawing.Point(32, 125);
            this.guna2TrackBar3.Maximum = 255;
            this.guna2TrackBar3.Minimum = 1;
            this.guna2TrackBar3.Name = "guna2TrackBar3";
            this.guna2TrackBar3.Size = new System.Drawing.Size(300, 23);
            this.guna2TrackBar3.TabIndex = 4;
            this.guna2TrackBar3.ThumbColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(113)))), ((int)(((byte)(255)))));
            this.guna2TrackBar3.Value = 200;
            this.guna2TrackBar3.Scroll += new System.Windows.Forms.ScrollEventHandler(this.guna2TrackBar3_Scroll);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Palatino Linotype", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(155, 160);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 19);
            this.label4.TabIndex = 7;
            this.label4.Text = "brightness #2";
            // 
            // guna2TrackBar4
            // 
            this.guna2TrackBar4.BackColor = System.Drawing.Color.Transparent;
            this.guna2TrackBar4.Location = new System.Drawing.Point(32, 182);
            this.guna2TrackBar4.Maximum = 255;
            this.guna2TrackBar4.Minimum = 1;
            this.guna2TrackBar4.Name = "guna2TrackBar4";
            this.guna2TrackBar4.Size = new System.Drawing.Size(300, 23);
            this.guna2TrackBar4.TabIndex = 6;
            this.guna2TrackBar4.ThumbColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(113)))), ((int)(((byte)(255)))));
            this.guna2TrackBar4.Value = 200;
            this.guna2TrackBar4.Scroll += new System.Windows.Forms.ScrollEventHandler(this.guna2TrackBar4_Scroll);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Palatino Linotype", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(155, 208);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(98, 19);
            this.label5.TabIndex = 9;
            this.label5.Text = "particle count";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // guna2TrackBar5
            // 
            this.guna2TrackBar5.BackColor = System.Drawing.Color.Transparent;
            this.guna2TrackBar5.Location = new System.Drawing.Point(32, 230);
            this.guna2TrackBar5.Maximum = 1000;
            this.guna2TrackBar5.Minimum = 1;
            this.guna2TrackBar5.Name = "guna2TrackBar5";
            this.guna2TrackBar5.Size = new System.Drawing.Size(300, 23);
            this.guna2TrackBar5.TabIndex = 8;
            this.guna2TrackBar5.ThumbColor = System.Drawing.Color.FromArgb(((int)(((byte)(160)))), ((int)(((byte)(113)))), ((int)(((byte)(255)))));
            this.guna2TrackBar5.Value = 200;
            this.guna2TrackBar5.Scroll += new System.Windows.Forms.ScrollEventHandler(this.guna2TrackBar5_Scroll);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(12)))), ((int)(((byte)(12)))), ((int)(((byte)(12)))));
            this.ClientSize = new System.Drawing.Size(628, 450);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.guna2TrackBar5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.guna2TrackBar4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.guna2TrackBar3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.guna2TrackBar2);
            this.Controls.Add(this.guna2TrackBar1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private Guna.UI2.WinForms.Guna2BorderlessForm guna2BorderlessForm1;
        private System.Windows.Forms.Label label1;
        private Guna.UI2.WinForms.Guna2TrackBar guna2TrackBar2;
        private Guna.UI2.WinForms.Guna2TrackBar guna2TrackBar1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private Guna.UI2.WinForms.Guna2TrackBar guna2TrackBar3;
        private System.Windows.Forms.Label label4;
        private Guna.UI2.WinForms.Guna2TrackBar guna2TrackBar4;
        private System.Windows.Forms.Label label5;
        private Guna.UI2.WinForms.Guna2TrackBar guna2TrackBar5;
    }
}

